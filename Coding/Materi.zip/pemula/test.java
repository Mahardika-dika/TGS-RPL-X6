public class test {
    public static void main(String[] args) {
        System.out.println("Nama: Mahardika Arfuri");
        System.out.println("Alamat: Jl. Raya Ki Ageng Gribig, Madyopuro, Kec. Kedungkandang, Kota Malang, Jawa Timur Perumahan Riverfront B51");
        System.out.println("SMP: MTSn 2 Kota Malang");
        System.out.println("No HP: +62 857-3264-9015");
    }
    
}