package Salary;

public class TesEmployee {
    public static void main(String[] args) {
        // Name, Salary
        Employee e1  = new Employee("Nabil", 2500000);
        Employee e2  = new Employee("Ardi", 2500000);
        Employee e3  = new Employee("Arfan", 2500000);
        Employee e4 = new Employee("Akbar", 2500000);

        e1.println();
        e2.println();
        e3.println();
        e4.println();

    }
}
