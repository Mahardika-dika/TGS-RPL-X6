function sayHello(name) {
  console.log("Hello" + name);
}
sayHello("Ardi");

function myFunction() {
  document.getElementById("r").innerHTML = 13 + 9 + 29;
}

function myFunction() {
  document.getElementById("perhitungan").innerHTML = (10 + 20) * 91 + 7;
}
