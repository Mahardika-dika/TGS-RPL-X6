package Project;

public class Student extends Person {

}
