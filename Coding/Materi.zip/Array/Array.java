package Array;

public class Array {
    public static void main(String[] args) {
        
        int[] umur;
        String Mapel[];
        String kota[] = new String[5];

        int umur[] = {23, 24, 25, 26, 27};
        String[] Mapel = {"RPL", "Mattematika", "Bahasa Jawa", "Bahasa Inggris", "IPA"};
        String kota[] = {"Malang, Batu, Surabaya, Solo, Jakarta"};

        System.out.println(kota[0]);
        System.out.println(Mapel[2]);
-
        
    }
}
